package hiring_project.shadow_assistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShadowAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
