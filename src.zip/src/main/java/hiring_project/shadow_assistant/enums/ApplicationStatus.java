package hiring_project.shadow_assistant.enums;

public enum ApplicationStatus {
    APPLIED, SCREENING, AIINTERVIEWED, SHORTLISTED, FINAL_INTERVIEW, REJECTED, SELECTED
}