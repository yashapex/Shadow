package hiring_project.shadow_assistant.enums;

public enum Verdict {
    ACCEPTED, REJECTED
}
