package hiring_project.shadow_assistant.enums;

public enum Role {
    RECRUITER,
    CANDIDATE
}
