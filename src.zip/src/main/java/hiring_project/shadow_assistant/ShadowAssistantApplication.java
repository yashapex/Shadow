package hiring_project.shadow_assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShadowAssistantApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShadowAssistantApplication.class, args);
	}

}
